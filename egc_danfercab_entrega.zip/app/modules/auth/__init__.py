from core.blueprints.base_blueprint import BaseBlueprint

auth_bp = BaseBlueprint('auth', __name__, template_folder='templates')

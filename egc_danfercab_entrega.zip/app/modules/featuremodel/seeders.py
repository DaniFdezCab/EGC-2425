from core.seeders.BaseSeeder import BaseSeeder


class FeaturemodelSeeder(BaseSeeder):

    def run(self):

        data = [
            # Create any Model object you want to make seed
        ]

        self.seed(data)
